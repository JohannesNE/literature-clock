library(testthat)
test_check("bit")



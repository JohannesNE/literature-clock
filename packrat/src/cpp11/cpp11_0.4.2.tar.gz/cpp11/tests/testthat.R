library(testthat)
library(cpp11)

test_check("cpp11")

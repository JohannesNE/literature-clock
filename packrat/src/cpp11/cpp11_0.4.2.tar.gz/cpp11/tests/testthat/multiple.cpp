[[cpp11::register]] int foo() { return 1; }

[[cpp11::register]] double bar(bool run) { return 1.0; }

[[cpp11::register]] bool baz(bool run, int value = 0) { return true; }

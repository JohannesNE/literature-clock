#' @keywords internal
#' @import rlang
"_PACKAGE"

.onLoad <- function(...) {
  run_on_load()
}

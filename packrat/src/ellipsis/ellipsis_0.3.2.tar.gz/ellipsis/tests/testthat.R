library(testthat)
library(ellipsis)

test_check("ellipsis")

library(testthat)
library(prettyunits)

test_check("prettyunits")

# englue() works

    Code
      err(englue("{'foo'}"), "Must use")
    Output
      <error/rlang_error>
      Error in `englue()`:
      ! Must use `{{`.
      i Use `glue::glue()` for interpolation with `{`.


# is_interactive() honors rlang_interactive option, above all else

    `rlang_interactive` must be `TRUE` or `FALSE`, not `NA`.


#' FAQ - Error: Must be used within a *selecting* function
#'
#' @includeRmd man/faq/selection-context.Rmd description
#'
#' @name faq-selection-context
NULL

#' FAQ - Note: Using an external vector in selections is ambiguous
#'
#' @includeRmd man/faq/external-vector.Rmd description
#'
#' @name faq-external-vector
NULL

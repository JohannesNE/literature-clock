#' @import rlang
#' @importFrom glue glue
#' @importFrom purrr discard map map_chr map_if map_lgl map2 map2_chr
#'   detect_index negate walk every compact
#' @keywords internal
"_PACKAGE"

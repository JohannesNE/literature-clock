library(testthat)
library(tzdb)

test_check("tzdb")

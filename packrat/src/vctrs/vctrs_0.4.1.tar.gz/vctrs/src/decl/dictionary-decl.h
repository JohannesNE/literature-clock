static inline uint32_t dict_key_size(SEXP x);

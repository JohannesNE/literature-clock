static
r_obj* syms_vec_ptype2_default;

static r_obj* cnd_signal_call;

# has useful print method

    Code
      unspecified()
    Output
      <unspecified> [0]


# checks input

    `lang` must be a string

